# Journals
Learning journals in Digital Methods for Historians class
